<?php
// Definujeme, že sme mimo hlavného priečinka galérie
define('ZENFOLDER', 'zp-core');
define('WEBPATH', 'gallery');

// Cesta k Zenphoto funkciám (upravte cestu ak je iná, ale v Docker štruktúre by mala sedieť)
require_once "gallery/zp-core/template-functions.php";
?>
<!DOCTYPE html>
<html class="no-js ss-preload" lang="sk">
<head>

    <!--- basic page needs
    ================================================== -->
    <meta charset="utf-8">
    <meta name="keywords" content="sport, photo, sportphoto, fotograf, sportovy fotograf">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
	<link rel="canonical" href="http://www.marekf.sk/">
	<meta name="robots" content="index, follow">
	<title>::Marek Findrik :: Sport Photo ::</title>
	
    <!-- CSS
    ================================================== -->
    <link rel="stylesheet" href="css/vendor.css">
    <link rel="stylesheet" href="css/styles.css">

    <!-- favicons
    ================================================== -->
    <link rel="apple-touch-icon" sizes="180x180" href="favicon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
    <link rel="manifest" href="site.webmanifest">

</head>

<body id="top">
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-9R3LKMSYK4"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-9R3LKMSYK4');
</script>

    <!-- # preloader
    ================================================== -->
    <div id="preloader">
        <div id="loader">
        </div>
    </div>


    <!-- # page wrap
    ================================================== -->
    <div class="s-pagewrap">

        <div class="circles">
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
        </div>


        <!-- ## site header 
        ================================================== -->
        <header class="s-header">

            <div class="header-mobile">
                <span class="mobile-home-link"><a href="index.html">MarekF</a></span>
                <a class="mobile-menu-toggle" href="#0"><span>Menu</span></a>
            </div>

            <div class="row wide main-nav-wrap">
                <nav class="column lg-12 main-nav">
                    <ul>
                        <li><a href="index.html" class="home-link">MarekF</a></li>
                        <li class="current"><a href="#intro" class="smoothscroll">Intro</a></li>
                        <li><a href="#about" class="smoothscroll">About</a></li>
                        <li><a href="#works" class="smoothscroll">Works</a></li>
                        <li><a href="#contact" class="smoothscroll">Napíšte</a></li>
                    </ul>
                </nav>
            </div>

        </header> <!-- end s-header -->


        <!-- ## main content
        ==================================================- -->
        <main class="s-content">


            <!-- ### intro
            ================================================== -->
            <section id="intro" class="s-intro target-section">

                <div class="row intro-content wide">

                    <div class="column">
                        <div class="text-pretitle with-line">
                            Ahoj
                        </div>

                        <h1 class="text-huge-title">
                            Som Marek Findrik</br>
                            Fotím pohyb v športe.</br>
                            Každý šport.<br>
                            A pohyb zvierat.
                        </h1>
                    </div>

                    <ul class="intro-social">
                            <li><a href="https://www.facebook.com/profile.php?id=100090307268798" target="blank">Facebook</a></li>
                            <li><a href="https://www.instagram.com/marekf_photo/" target="blank">Instagram</a></li>
                            <li><a href="https://marekfindrik.pixieset.com/" target="blank">Pixieset</a></li>
                    </ul>

                </div> <!-- end intro content -->

                <a href="#about" class="intro-scrolldown smoothscroll">
                    <svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill-rule="evenodd" clip-rule="evenodd"><path d="M11 21.883l-6.235-7.527-.765.644 7.521 9 7.479-9-.764-.645-6.236 7.529v-21.884h-1v21.883z"/></svg>
                </a>

            </section> <!-- end s-intro -->


            <!-- ### about
            ================================================== -->
            <section id="about" class="s-about target-section">


                <div class="row about-info wide" data-animate-block>

                    <div class="column lg-6 md-12 about-info__pic-block">
                        <img src="images/about-photo.jpg" 
                             srcset="images/mareklogoBW3.png 1x, images/mareklogoBW3.png 2x" alt="" class="about-info__pic" data-animate-el>
                    </div>

                    <div class="column lg-6 md-12">
                        <div class="about-info__text" >

                            <h2 class="text-pretitle with-line" data-animate-el>
                                About
                            </h2>
                            <p class="attention-getter" data-animate-el>
                                Fotenie je mojím koníčkom. Mojím primárnym záujmom je fotenie pohybu v športe. Každý šport má svoje čaro. Tomu sa vyrovná len pohyb zvierat.
                            </p>
                            

                        </div>
                    </div>
                </div> <!-- about-info -->


                <!--
                <div class="row about-expertise" data-animate-block>
                    <div class="column lg-12">

                        <h2 class="text-pretitle" data-animate-el>Expertise</h2>

                        <ul class="skills-list h1" data-animate-el>
                            <li>Visual Design</li>
                            <li>Branding Identity</li>
                            <li>UI Design</li>
                            <li>Product Design</li>
                            <li>Prototyping</li>
                            <li>Illustration</li>
                        </ul>

                    </div>
                </div>
                -->
                 <!-- end about-expertise -->


                <div class="row about-timelines" data-animate-block>

                    <div class="column lg-6 tab-12">

                        <h2 class="text-pretitle" data-animate-el>
                            Športy
                        </h2>

                        <div class="timeline" data-animate-el>

                            <div class="timeline__block">
                                <div class="timeline__bullet"></div>
                                <div class="timeline__header">
                                    <h4 class="timeline__title">Lopta</h3>
                                    <h5 class="timeline__meta">Loptové hry. Fšetky farby, veľkosti a tvary.</br>Rýchlosť, dynamika, taktika a spolupráca.</h5>
                                    <p class="timeline__timeframe">HK Košice, ŠŠK Bernolákova, FK Slávia TU Košice, ...</p>
                                </div>
                                <div class="timeline__desc">
                                    <img src="images/portfolio/lopta.png" srcset="images/portfolio/lopta.png 1x, images/portfolio/lopta.png 2x" alt="Lopta" class="about-info__pic" data-animate-el style="width:100%">
                                </div>
                            </div>
    
                            <div class="timeline__block">
                                <div class="timeline__bullet"></div>
                                <div class="timeline__header">
                                    <h4 class="timeline__title">Pálka</h4>
                                    <h5 class="timeline__meta">Softball. Rýchly a dynamický šport.</br>Šport pre každú vekovú hranicu.</h5>
                                    <p class="timeline__timeframe">Crows Košice, Trnava Panthers, ...</p>
                                </div>
                                <div class="timeline__desc">
                                    <img src="images/portfolio/palka.png" srcset="images/portfolio/palka.png 1x, images/portfolio/palka.png 2x" alt="Pálka" class="about-info__pic" data-animate-el style="width:100%">
                                </div>
                            </div>
    
       						<div class="timeline__block">
                                <div class="timeline__bullet"></div>
                                <div class="timeline__header">
                                    <h4 class="timeline__title">Hokejka</h4>
                                    <h5 class="timeline__meta">Dynamika, rýchlosť, kontakt, sila, um.</br>To je hokej a nemusí byť profesionálny.</h5>
                                    <p class="timeline__timeframe">HC Košice, amaterske kluby, ...</p>
                                </div>
                                <div class="timeline__desc">
                                    <img src="images/portfolio/hokejka.png" srcset="images/portfolio/hokejka.png 1x, images/portfolio/hokejka.png 2x" alt="Hokejka" class="about-info__pic" data-animate-el style="width:100%">
                                </div>
                            </div>    
                        </div> <!-- end timeline -->

                    </div> <!-- end column -->

                    <div class="column lg-6 tab-12">

                        <h2 class="text-pretitle" data-animate-el>
                            &nbsp;
                        </h2>

                        <div class="timeline" data-animate-el>

                            <div class="timeline__block">
                                <div class="timeline__bullet"></div>
                                <div class="timeline__header">
                                    <h4 class="timeline__title">Kolesá</h3>
                                    <h5 class="timeline__meta">Dynamika a sila či už motora alebo nôh.</br>K tomu či už hluk alebo prach.</h5>
                                    <p class="timeline__timeframe">Šarkan Košice</br>...</p>
                                </div>
                                <div class="timeline__desc">
                                    <img src="images/portfolio/kolesa.png" srcset="images/portfolio/kolesa.png 1x, images/portfolio/kolesa.png 2x" alt="Kolesá" class="about-info__pic" data-animate-el style="width:100%">
                                </div>
                            </div>
    
                            <div class="timeline__block">
                                <div class="timeline__bullet"></div>
                                <div class="timeline__header">
                                    <h4 class="timeline__title">4 nohy</h4>
                                    <h5 class="timeline__meta">4 nohy v pohybe je niečo nádherné a neskutočné.</br>Súhra svalov, sršiaca energia z každého svalu.</h5>
                                    <p class="timeline__timeframe">TJ Slávia UVLF, ...</p>
                                </div>
                                <div class="timeline__desc">
                                    <img src="images/portfolio/4nohy.png" srcset="images/portfolio/4nohy.png 1x, images/portfolio/4nohy.png 2x" alt="4 nohy" class="about-info__pic" data-animate-el style="width:100%">
                                </div>
                            </div>

                            <div class="timeline__block">
                                <div class="timeline__bullet"></div>
                                <div class="timeline__header">
                                    <h4 class="timeline__title">Queen</h4>
                                    <h5 class="timeline__meta">Kráľovná športu.</br>Symbióza rýchlosti, sily a koordinácie.</h5>
                                    <p class="timeline__timeframe">Atletika Košice, TJ Slávia TU Košice, ...</p>
                                </div>
                                <div class="timeline__desc">
                                    <img src="images/portfolio/queen.png" srcset="images/portfolio/queen.png 1x, images/portfolio/queen.png 2x" alt="Queen" class="about-info__pic" data-animate-el style="width:100%">
                                </div>
                            </div>
    
                        </div> <!-- end timeline -->
                        
                    </div> <!-- end column -->


                </div> <!-- end about-timelines -->

            </section> <!-- end s-about -->


            <!-- ### works
            ================================================== -->
            <section id="works" class="s-works target-section">


                <div class="row works-portfolio">

                    <div class="column lg-12" data-animate-block>

                        <h2 class="text-pretitle" data-animate-el>
                            Posledné akcie
                        </h2>
                        <p class="h1" data-animate-el>
                            Nech sa páči, moje posledné fotenia.
                        </p>
    
                        <ul class="folio-list row block-lg-one-half block-stack-on-1000">

                            <?php
    // Získame 6 najnovších albumov (podľa ID alebo dátumu)
    // 'latest-updated' zoradí podľa poslednej zmeny, 'latest' podľa ID
    $latest_albums = getAlbumStatistic(6, 'latest'); 
    
    foreach ($latest_albums as $albumData) {
        // Vytvoríme objekt albumu, aby sme mohli ťahať dáta
        $album = new Album(new Gallery(), $albumData['folder']);
        
        // Nastavíme tento album ako "aktuálny" pre Zenphoto funkcie
        makeAlbumCurrent($album);
        
        // Získame URL k náhľadovému obrázku
        $thumbImage = $album->getAlbumThumbImage();
        $thumbUrl = $thumbImage->getThumb(); 
        
        // Alternatívne: Ak chceš presný výrez (crop), použi toto:
        // $thumbUrl = $thumbImage->getCustomImage(null, 600, 400, 600, 400, null, null, true);
    ?>

    <li class="folio-list__item column" data-animate-el>
        <a class="folio-list__item-link" href="<?php echo htmlspecialchars(getAlbumLinkURL()); ?>">
            <div class="folio-list__item-pic">
                <img src="<?php echo $thumbUrl; ?>" 
                     alt="<?php printAlbumTitle(); ?>"
                     style="width: 100%; height: auto; object-fit: cover;">
            </div>
            
            <div class="folio-list__item-text">
                <div class="folio-list__item-cat">
                    <?php printAlbumDate(); ?>
                </div>
                <div class="folio-list__item-title">
                    <?php printAlbumTitle(); ?>
                </div>
            </div>
        </a>
    </li> 

    <?php
    } // Koniec cyklu
    ?>--end folio-list__item -->

                        </ul> <!-- end folio-list -->

                    </div> <!-- end column -->


                    <!-- Modal Templates Popup
                    -------------------------------------------- -->
                    <div id="modal-01" hidden>
                        <div class="modal-popup">
                                           
                            <div class="modal-popup__desc">
                                <h5>Iuventa Michalovce - Házená Kynžvart</h5>
                                <table style="margin-top:30px">
                                	<tr>
                                		<td><img src="images/portfolio/gallery/gal_01_01.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_01_02.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_01_03.jpg"></td>
                                	</tr>
                                	<tr>
                                		<td><img src="images/portfolio/gallery/gal_01_04.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_01_05.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_01_06.jpg"></td>
                                	</tr>
                                	<tr>
                                		<td><img src="images/portfolio/gallery/gal_01_07.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_01_08.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_01_09.jpg"></td>
                                	</tr>
                                </table>
                                <ul class="modal-popup__cat">
                                    <li>MOL liga</li>
                                    <li>Ženy</li>
                                </ul>
                            </div>
                
                            <a href="https://galleries.page.link/PBccr" class="modal-popup__details" target="blank">Galeria</a>
                        </div>
                    </div> <!-- end modal -->

                    <div id="modal-02" hidden>
                        <div class="modal-popup">
                            
                            <div class="modal-popup__desc">
                                <h5>HK Košice - HO Slovan Modra</h5>
                                <table style="margin-top:30px">
                                	<tr>
                                		<td><img src="images/portfolio/gallery/gal_02_01.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_02_02.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_02_03.jpg"></td>
                                	</tr>
                                	<tr>
                                		<td><img src="images/portfolio/gallery/gal_02_04.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_02_05.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_02_06.jpg"></td>
                                	</tr>
                                	<tr>
                                		<td><img src="images/portfolio/gallery/gal_02_07.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_02_08.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_02_09.jpg"></td>
                                	</tr>
                                </table>
                                <ul class="modal-popup__cat">
                                    <li>NHE Liga</li>
                                    <li>Muži</li>
                                </ul>
                            </div>
                
                            <a href="https://galleries.page.link/y7RvX" class="modal-popup__details" target="blank">Galeria</a>
                            
                        </div>
                    </div> <!-- end modal -->

                    <div id="modal-03" hidden>
                        <div class="modal-popup">
                                            
                            <div class="modal-popup__desc">
                                <h5>RIM Slávia TU Košice - BK Oravan Námestovo</h5>
                                <table style="margin-top:30px">
                                	<tr>
                                		<td><img src="images/portfolio/gallery/gal_03_01.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_03_02.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_03_03.jpg"></td>
                                	</tr>
                                	<tr>
                                		<td><img src="images/portfolio/gallery/gal_03_04.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_03_05.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_03_06.jpg"></td>
                                	</tr>
                                	<tr>
                                		<td><img src="images/portfolio/gallery/gal_03_07.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_03_08.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_03_09.jpg"></td>
                                	</tr>
                                </table>
                                <ul class="modal-popup__cat">
                                    <li>Basketbal</li>
                                    <li>Muži</li>
                                </ul>
                            </div>
                
                            <a href="https://eu.zonerama.com/MarekFindrik/Album/12788401" class="modal-popup__details" target="blank">Galeria</a>
                        </div>
                    </div> <!-- end modal -->

                    <div id="modal-04" hidden>
                        <div class="modal-popup">
                            
                            <div class="modal-popup__desc">
                                <h5>Podpor Pohyb Košice</h5>
                                <table style="margin-top:30px">
                                	<tr>
                                		<td><img src="images/portfolio/gallery/gal_04_01.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_04_02.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_04_03.jpg"></td>
                                	</tr>
                                	<tr>
                                		<td><img src="images/portfolio/gallery/gal_04_04.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_04_05.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_04_06.jpg"></td>
                                	</tr>
                                	<tr>
                                		<td><img src="images/portfolio/gallery/gal_04_07.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_04_08.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_04_09.jpg"></td>
                                	</tr>
                                </table>
                                <ul class="modal-popup__cat">
                                    <li>Futsal</li>
                                    <li>Ženy</li>
                                </ul>
                            </div>
                
                            <a href="https://galleries.page.link/xd7YN" class="modal-popup__details" target="blank">Galeria</a>
                        </div>
                    </div> <!-- end modal -->

                    <div id="modal-05" hidden>
                        <div class="modal-popup">

                            <div class="modal-popup__desc">
                                <h5>ŠŠK Bernolákova Košice - Iuventa Michalovce</h5>
                                <table style="margin-top:30px">
                                	<tr>
                                		<td><img src="images/portfolio/gallery/gal_05_01.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_05_02.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_05_03.jpg"></td>
                                	</tr>
                                	<tr>
                                		<td><img src="images/portfolio/gallery/gal_05_04.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_05_05.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_05_06.jpg"></td>
                                	</tr>
                                	<tr>
                                		<td><img src="images/portfolio/gallery/gal_05_07.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_05_08.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_05_09.jpg"></td>
                                	</tr>
                                </table>
                                <ul class="modal-popup__cat">
                                    <li>Hádzaná</li>
                                    <li>Mládež</li>
                                </ul>
                            </div>
                
                            <a href="https://galleries.page.link/LwvnN" class="modal-popup__details" target="blank">Galeria</a>
                        </div>
                    </div> <!-- end modal -->

                    <div id="modal-06" hidden>
                        <div class="modal-popup">
                            
                            <div class="modal-popup__desc">
                                <h5>HC Motor Zaporizhzhia - RK Izviđač Agram</h5>
                                <table style="margin-top:30px">
                                	<tr>
                                		<td><img src="images/portfolio/gallery/gal_06_01.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_06_02.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_06_03.jpg"></td>
                                	</tr>
                                	<tr>
                                		<td><img src="images/portfolio/gallery/gal_06_04.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_06_05.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_06_06.jpg"></td>
                                	</tr>
                                	<tr>
                                		<td><img src="images/portfolio/gallery/gal_06_07.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_06_08.jpg"></td>
                                		<td><img src="images/portfolio/gallery/gal_06_09.jpg"></td>
                                	</tr>
                                </table>
                                <ul class="modal-popup__cat">
                                    <li>EHF Cup</li>
                                    <li>Muži</li>
                                </ul>
                            </div>
                
                            <a href="https://galleries.page.link/V59g9" class="modal-popup__details" target="blank">Galeria</a>
                        </div>
                    </div> <!-- end modal -->

                </div> <!-- end works-portfolio -->


                <!--
                <div class="row testimonials">
                    <div class="column lg-12" data-animate-block>
        
                        <div class="swiper-container testimonial-slider" data-animate-el>
        
                            <div class="swiper-wrapper">

                                <div class="testimonial-slider__slide swiper-slide">
                                    <div class="testimonial-slider__author">
                                        <img src="images/avatars/user-02.jpg" alt="Author image" class="testimonial-slider__avatar">
                                        <cite class="testimonial-slider__cite">
                                            <strong>Tim Cook</strong>
                                            <span>CEO, Apple</span>
                                        </cite>
                                    </div>
                                    <p>
                                    Molestiae incidunt consequatur quis ipsa autem nam sit enim magni. Voluptas tempore rem. 
                                    Explicabo a quaerat sint autem dolore ducimus ut consequatur neque.  Nisi dolores quaerat fuga rem nihil nostrum.
                                    Laudantium quia consequatur molestias delectus culpa.
                                    </p>
                                </div> <!-- end testimonial-slider__slide -->
                
                  <!--              <div class="testimonial-slider__slide swiper-slide">
                                    <div class="testimonial-slider__author">
                                        <img src="images/avatars/user-03.jpg" alt="Author image" class="testimonial-slider__avatar">
                                        <cite class="testimonial-slider__cite">
                                            <strong>Sundar Pichai</strong>
                                            <span>CEO, Google</span>
                                        </cite>
                                    </div>
                                    <p>
                                    Excepturi nam cupiditate culpa doloremque deleniti repellat. Veniam quos repellat voluptas animi adipisci.
                                    Nisi eaque consequatur. Voluptatem dignissimos ut ducimus accusantium perspiciatis.
                                    Quasi voluptas eius distinctio. Atque eos maxime.
                                    </p>
                                </div> <!-- end testimonial-slider__slide -->
                
                  <!--              <div class="testimonial-slider__slide swiper-slide">
                                    <div class="testimonial-slider__author">
                                        <img src="images/avatars/user-01.jpg" alt="Author image" class="testimonial-slider__avatar">
                                        <cite class="testimonial-slider__cite">
                                            <strong>Satya Nadella</strong>
                                            <span>CEO, Microsoft</span>
                                        </cite>
                                    </div>
                                    <p>
                                    Repellat dignissimos libero. Qui sed at corrupti expedita voluptas odit. Nihil ea quia nesciunt. Ducimus aut sed ipsam.  
                                    Autem eaque officia cum exercitationem sunt voluptatum accusamus. Quasi voluptas eius distinctio.
                                    Voluptatem dignissimos ut.
                                    </p>
                                </div> <!-- end testimonial-slider__slide -->
        
                  <!--              <div class="testimonial-slider__slide swiper-slide">
                                    <div class="testimonial-slider__author">
                                        <img src="images/avatars/user-06.jpg" alt="Author image" class="testimonial-slider__avatar">
                                        <cite class="testimonial-slider__cite">
                                            <strong>Jeff Bezos</strong>
                                            <span>CEO, Amazon</span>
                                        </cite>
                                    </div>
                                    <p>
                                    Nunc interdum lacus sit amet orci. Vestibulum dapibus nunc ac augue. Fusce vel dui. In ac felis 
                                    quis tortor malesuada pretium. Curabitur vestibulum aliquam leo. Qui sed at corrupti expedita voluptas odit. 
                                    Nihil ea quia nesciunt. Ducimus aut sed ipsam.
                                    </p>
                                </div> <!-- end testimonial-slider__slide -->
            
              <!--              </div> <!-- end swiper-wrapper -->
        
              <!--              <div class="swiper-pagination"></div>
        
                        </div> <!-- end swiper-container -->
        
              <!--      </div> <!-- end column -->
              <!--  </div> <!-- end row testimonials -->

            </section> <!-- end s-works -->


            <!-- ### contact
            ================================================== -->
            <section id="contact" class="s-contact target-section">

                <div class="row contact-top">
                    <div class="column lg-12">
                        <h2 class="text-pretitle">
                            Ozvi te sa
                        </h2>

                        <p class="h1">
                            Budem rád za každý kontakt.
                            Či už budete mať otázku o fotení alebo 
                            budete mať záujem o moje služby - píšte.
                        </p>
                    </div>
                </div> <!-- end contact-top -->

                <div class="row contact-bottom">
                    <div class="column lg-3 md-5 tab-6 stack-on-550 contact-block">
                        <h3 class="text-pretitle">Počúvam Vás:</h3>
                        <p class="contact-links">
                            <a href="mailto:foto@marekf.sk" class="mailtoui">foto at marekf.sk</a> <br>
                            <a href="tel:+421940541‬‬‬968‬‬‬">+421 940 541‬‬‬ 968‬‬‬</a>
                        </p>
                    </div>
                    <div class="column lg-4 md-5 tab-6 stack-on-550 contact-block">
                        <h3 class="text-pretitle">Linky</h3>
                        <ul class="contact-social">
                            <li><a href="https://www.facebook.com/profile.php?id=100090307268798" target="blank">Facebook</a></li>
                            <li><a href="https://www.instagram.com/marekf_photo/" target="blank">Instagram</a></li>
                            <li><a href="https://bit.ly/marekfoto" target="blank">Zonerama</a></li>
							<li><a href="https://marekfindrik.pixieset.com/" target="blank">Pixieset</a></li>
                        </ul>
                    </div>
                    <div class="column lg-4 md-12 contact-block">
                        <a href="mailto:foto@marekf.sk" class="mailtoui btn btn--medium u-fullwidth contact-btn">Píšem :)</a>
                    </div>
                </div> <!-- end contact-bottom -->

            </section> <!-- end contact -->

        </main> <!-- end s-content -->


        <!-- ## footer
        ================================================== -->
        <footer class="s-footer">

            <div class="row">
                <div class="column ss-copyright">
                    <span>© Copyright Luther 2021</span> 
                    <span>Design by <a href="https://www.styleshout.com/">StyleShout</a></span>
                </div>

                <div class="ss-go-top">
                    <a class="smoothscroll" title="Back to Top" href="#top">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill-rule="evenodd" clip-rule="evenodd"><path d="M11 2.206l-6.235 7.528-.765-.645 7.521-9 7.479 9-.764.646-6.236-7.53v21.884h-1v-21.883z"/></svg>
                    </a>
                </div>
            </div>

        </footer> <!-- end s-footer -->

    </div> <!-- end -s-pagewrap -->


    <!-- Java Script
    ================================================== -->
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>

</body>
</html>